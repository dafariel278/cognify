# COGNIFY v2 — Your Skills, Verified On-Chain

> Privacy-first skill verification infrastructure. Built on COTI Network.

---

## What is COGNIFY?

COGNIFY is a platform where job seekers prove their cognitive abilities to employers — without exposing their identity, exact scores, or personal data. Every test result is encrypted on COTI Network using native MPC encryption.

**The problem we solve:** In 2026, ~46% of CVs contain AI-generated or exaggerated content. Background checks cost $50–200 per candidate. And every job application forces candidates to give away personal data to companies they've never met. COGNIFY fixes all of this.

---

## Key Features

- **3 validated assessments** — Memory Sequence, Pattern Logic, Speed Math
- **On-chain encrypted scores** — COTI MPC encryption, only wallet owner can decrypt
- **SkillProof Badges** — Bronze/Silver/Gold with global percentile rank
- **Consent-based disclosure** — per-company control: tier only → percentile → score → full report
- **Recruiter verification** — free, instant, no login required
- **BRM rewards** — earn tokens on every badge earned

---

## Setup in GitHub Codespace

### 1. Create repo and open Codespace
```bash
# Create new GitHub repo "cognify", open Codespace
```

### 2. Initialize project
```bash
npx create-next-app@14.2.5 . --typescript --tailwind --eslint --app --no-src-dir --import-alias "@/*" --use-npm
```

### 3. Install dependencies
```bash
npm install framer-motion lucide-react class-variance-authority clsx tailwind-merge
npm install @coti-io/coti-ethers@1.0.5
```

### 4. Upload and extract project
```bash
# Upload cognify2-project.zip via Explorer panel, then:
unzip cognify2-project.zip -d /tmp/c2
cp -r /tmp/c2/cognify2/app/* ./app/
cp -r /tmp/c2/cognify2/components ./
cp -r /tmp/c2/cognify2/context ./
cp -r /tmp/c2/cognify2/hooks ./
cp -r /tmp/c2/cognify2/lib ./
cp /tmp/c2/cognify2/tailwind.config.ts /tmp/c2/cognify2/next.config.mjs ./
```

### 5. Configure environment
```bash
cp .env.example .env.local
# Fill in COTI_MINTER_PRIVATE_KEY and NEXT_PUBLIC_CONTRACT_ADDRESS
```

### 6. Deploy BRM Token on COTI Testnet
1. Open https://smithery.ai → connect COTI MCP Server
2. Prompt: `Using COTI MCP SERVER. Deploy a 6-decimal private token on COTI TESTNET named BrainMint, symbol BRM.`
3. Fund minter wallet via faucet: https://docs.coti.io/coti-documentation/networks/testnet/faucet
4. Prompt: `Wallet funded. Deploy the token.`
5. Copy contract address → paste in `.env.local`

### 7. Run
```bash
npm run dev
# In Ports tab: set port 3000 to Public
```

---

## Project Structure

```
cognify2/
├── app/
│   ├── page.tsx                           # Landing page (all sections)
│   ├── test/[slug]/page.tsx               # Assessment flow
│   ├── passport/page.tsx                  # Skill Passport dashboard
│   ├── verify/page.tsx                    # Recruiter verify landing
│   └── verify/[address]/page.tsx          # Public badge profile
├── components/
│   ├── layout/Navbar.tsx                  # Sticky nav
│   ├── HeroSection.tsx                    # Hero with animated passport
│   ├── LandingSections.tsx                # All landing page sections
│   ├── tests/
│   │   ├── MemorySequence.tsx             # Game 1
│   │   ├── PatternLogic.tsx               # Game 2
│   │   ├── SpeedMath.tsx                  # Game 3
│   │   └── MintResult.tsx                 # Post-test + mint flow
│   └── passport/
│       ├── BadgeCard.tsx                  # Reusable badge display
│       └── ConsentPanel.tsx               # Per-company disclosure control
├── context/WalletContext.tsx              # Wallet + COTI onboarding
├── lib/
│   ├── types.ts                           # All shared types
│   ├── utils.ts
│   ├── data/
│   │   ├── tests.ts                       # Test definitions + benchmark data
│   │   └── storage.ts                     # localStorage abstraction
│   └── actions/
│       └── mint-badge.ts                  # Server action: mint BRM
```

---

## COTI Testnet

| | |
|---|---|
| Chain ID | 7082400 |
| RPC | https://testnet.coti.io/rpc |
| Explorer | https://testnet.cotiscan.io |
| Faucet | https://docs.coti.io/coti-documentation/networks/testnet/faucet |

---

## Deploy to Vercel

```bash
vercel --prod
# Add env vars in Vercel dashboard
```

---

## Contest Submission Checklist

- [ ] App live on Vercel with public URL
- [ ] BRM token deployed on COTI Testnet
- [ ] Record demo: test → badge → consent control → recruiter verify
- [ ] Post on X tagging @COTINetwork with app URL + video
- [ ] Submit at https://forms.gle/2Xan4qnVTo7w9itF9

**Total cost: $0** — Testnet, GitHub Codespace free tier, Vercel free tier.

---

Built for the [COTI Vibe Code Challenge](https://stay.coti.io/vibe-coding) · Deadline March 31, 2026
